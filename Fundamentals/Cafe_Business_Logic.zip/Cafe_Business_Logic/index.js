function sayhello(fname) {
    console.log("Hello" + fname)
}

sayhello("Jonathan")

function add(num1,num2) {
    var sum = num1 + num2
    console.log(sum)
    return sum
}
var answer = add(2,2)
console.log(answer)