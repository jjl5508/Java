
public class Runner {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Bat man = new Bat("Asterik", 300);
		System.out.println(man.getName());
		man.attackTown();
		man.attackTown();
		man.attackTown();
		man.eatHumans();
		man.eatHumans();
		man.fly();
		man.fly();
	}

}
