package com.jonathanlee.phone;

public interface Jonathan {
	default boolean life() {
		return true;
	}
}
