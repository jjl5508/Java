package com.jonathan.languages.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.jonathan.languages.models.Languages;

@Repository
public interface LangRepo extends CrudRepository<Languages, Long> {
	List <Languages> findAll();
}
